# 📦 Distributed File Storage Backend API (Production-Ready)

## 🚀 Overview
A scalable backend system similar to Google Drive or Dropbox that supports file uploads, storage, and retrieval using cloud infrastructure.

---

## 🧰 Tech Stack
- Node.js + Express
- AWS S3 (cloud storage)
- PostgreSQL (metadata storage)
- Multer (file uploads)

---

## ⚙️ Features
- File upload API
- Cloud storage integration (AWS S3)
- Metadata storage in PostgreSQL
- Scalable backend architecture
- Ready for signed URL support

---

## 🏗️ Architecture

Client → API → Service Layer → S3 Storage + PostgreSQL

---

## ▶️ Getting Started

```bash
git clone <repo>
cd file-storage-backend
npm install
cp .env_example_environment_variables .env
npm run dev
```

---

## 🔐 Environment Variables

```
PORT=5000
AWS_ACCESS_KEY=your_key
AWS_SECRET_KEY=your_secret
S3_BUCKET=your_bucket
POSTGRES_URI=postgres://user:pass@localhost:5432/filedb
```

---

## 📡 API Endpoints

| Method | Endpoint        | Description      |
|--------|----------------|------------------|
| POST   | /api/files/upload | Upload file     |

---

## 🧠 What This Demonstrates
- Cloud storage integration
- File handling at scale
- Backend architecture design
- Secure data handling

---

## 💡 Why This Project Stands Out

Most portfolios:
- ❌ No cloud integration
- ❌ No large file handling

This project:
- ✅ Uses AWS S3
- ✅ Handles file uploads properly
- ✅ Demonstrates real-world backend systems

---

## 🚧 Future Improvements
- Signed URLs for secure access
- File versioning
- Chunked uploads for large files
- CDN integration
- Access control permissions

---

## 👨‍💻 Author
Brandon De Armas
