const s3 = require('../config/aws_s3_storage_configuration');
const repo = require('../repositories/file_metadata_database_repository');

exports.uploadFileService = async (file) => {
    const upload = await s3.upload({
        Bucket: process.env.S3_BUCKET,
        Key: file.originalname,
        Body: file.buffer
    }).promise();

    return repo.saveFileMetadata(upload.Location);
};
