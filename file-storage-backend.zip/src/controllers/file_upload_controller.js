const service = require('../services/file_storage_business_logic_service');

exports.uploadFileController = async (req, res) => {
    const result = await service.uploadFileService(req.file);
    res.json(result);
};
