const db = require('../config/postgres_database_connection_config');

exports.saveFileMetadata = async (url) => {
    const result = await db.query(
        'INSERT INTO files(url) VALUES($1) RETURNING *',
        [url]
    );
    return result.rows[0];
};
