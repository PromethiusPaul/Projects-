const express = require('express');
require('dotenv').config();

const fileRoutes = require('./routes/file_routes_definition');

const app = express();

app.use('/api/files', fileRoutes);

app.listen(process.env.PORT || 5000, () => {
    console.log('Server running');
});
