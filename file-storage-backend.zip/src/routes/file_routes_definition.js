const express = require('express');
const router = express.Router();

const controller = require('../controllers/file_upload_controller');
const upload = require('../middleware/file_upload_middleware_handler');

router.post('/upload', upload.single('file'), controller.uploadFileController);

module.exports = router;
