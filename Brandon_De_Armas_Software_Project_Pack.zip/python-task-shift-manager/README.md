# Python Task & Shift Manager

A command-line Python application for creating, tracking, and completing shift tasks.

## Skills demonstrated
- Python scripting
- File I/O with JSON persistence
- CLI menu design
- Data modeling with dataclasses

## How to run
```bash
python main.py
```

## Resume bullets
- Developed a Python command-line task manager for shift coordination with JSON-based data persistence and completion tracking.
- Modeled task records with dataclasses and implemented CRUD-style workflows for assignment and status updates.
- Structured the application around reusable functions to improve readability and maintainability.
