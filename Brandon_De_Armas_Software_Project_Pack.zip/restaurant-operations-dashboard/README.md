# Restaurant Operations Dashboard

A lightweight front-end dashboard built with HTML, CSS, and JavaScript to track restaurant sales, labor percentage, inventory alerts, and guest satisfaction.

## Why this helps your software resume
This project shows:
- Front-end development with HTML/CSS/JavaScript
- Local storage data persistence
- Business logic tied to real operations metrics
- UI design and user interaction handling

## How to run
Open `index.html` in a browser.

## Resume bullets
- Built a browser-based operations dashboard using JavaScript, HTML, and CSS to track sales, labor cost, inventory alerts, and guest satisfaction metrics.
- Implemented local storage persistence and business-rule alerts to simulate real-time restaurant performance monitoring.
- Designed a responsive interface focused on operational decision-making and usability.
