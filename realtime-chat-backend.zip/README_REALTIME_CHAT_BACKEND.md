# 💬 Real-Time Chat Backend API (Production-Ready)

## 🚀 Overview
A scalable real-time messaging backend similar to Discord/Slack.  
Built to demonstrate WebSockets, event-driven architecture, and system scalability.

---

## 🧰 Tech Stack
- Node.js + Express
- Socket.IO (WebSockets)
- PostgreSQL
- Redis (Pub/Sub)

---

## ⚙️ Features
- Real-time messaging
- Room-based chat
- Message persistence
- Event-driven architecture
- Scalable with Redis Pub/Sub

---

## 🏗️ Architecture

Client → WebSocket Server → Event Handlers → Services → Repositories → Database

---

## ▶️ Getting Started

```bash
git clone <repo>
cd realtime-chat-backend
npm install
cp .env_example_environment_variables .env
npm run dev
```

---

## 📡 Events

### Join Room
join_room_event

### Send Message
send_message_event

### Receive Message
receive_message_event

---

## 🧠 What This Demonstrates
- Real-time backend engineering
- WebSocket communication
- Scalable system design
- Event-driven architecture

---

## 🚧 Future Improvements
- Authentication for sockets (JWT)
- Typing indicators
- Read receipts
- Horizontal scaling with Redis adapter

---

## 👨‍💻 Author
Brandon De Armas
