const db = require('../config/postgres_database_connection_config');

exports.saveMessage = async ({ userId, roomId, message }) => {
    const result = await db.query(
        'INSERT INTO messages(user_id, room_id, message) VALUES($1,$2,$3) RETURNING *',
        [userId, roomId, message]
    );
    return result.rows[0];
};
