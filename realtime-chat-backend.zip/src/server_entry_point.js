const express = require('express');
const http = require('http');
require('dotenv').config();

const setupWebSocket = require('./config/websocket_server_configuration');

const app = express();
const server = http.createServer(app);

setupWebSocket(server);

server.listen(process.env.PORT || 5000, () => {
    console.log('Server running');
});
