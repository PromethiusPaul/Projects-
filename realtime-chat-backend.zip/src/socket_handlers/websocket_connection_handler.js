const messageHandler = require('./message_event_handler');

module.exports = (socket) => {
    console.log('User connected:', socket.id);

    socket.on('join_room_event', (roomId) => {
        socket.join(roomId);
    });

    socket.on('send_message_event', (data) => {
        messageHandler(socket, data);
    });

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
};
