const service = require('../services/chat_message_business_logic_service');

module.exports = async (socket, data) => {
    const saved = await service.processAndStoreMessage(data);
    socket.to(data.roomId).emit('receive_message_event', saved);
};
