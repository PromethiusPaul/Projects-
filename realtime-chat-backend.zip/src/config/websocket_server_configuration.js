const { Server } = require('socket.io');
const connectionHandler = require('../socket_handlers/websocket_connection_handler');

module.exports = (server) => {
    const io = new Server(server, {
        cors: { origin: '*' }
    });

    io.on('connection', connectionHandler);
};
