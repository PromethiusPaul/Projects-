const repo = require('../repositories/chat_message_database_repository');

exports.processAndStoreMessage = async (data) => {
    return repo.saveMessage(data);
};
