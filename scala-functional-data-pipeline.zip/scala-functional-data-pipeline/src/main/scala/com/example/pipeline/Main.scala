package com.example.pipeline

object Main {
  def main(args: Array[String]): Unit = {
    val inputPath = args.headOption.getOrElse("data/input/employees.csv")
    val reportPath = args.lift(1).getOrElse("data/output/report.json")
    val errorsPath = args.lift(2).getOrElse("data/output/errors.json")

    if (!FileIO.exists(inputPath)) {
      Console.err.println(s"Input file not found: $inputPath")
      sys.exit(1)
    }

    val lines = FileIO.readLines(inputPath)
    val decoded = Pipeline.decode(lines)
    val (errors, validRecords) = Pipeline.validate(decoded)
    val summaries = Pipeline.summarize(validRecords)
    val report = Pipeline.buildReport(decoded.size, errors, summaries)

    FileIO.writeText(reportPath, JsonWriter.reportToJson(report))
    FileIO.writeText(errorsPath, JsonWriter.errorsToJson(errors))

    println("Functional data pipeline completed.")
    println(s"Processed records: ${report.processed}")
    println(s"Valid records: ${report.valid}")
    println(s"Invalid records: ${report.invalid}")
    println(s"Report written to: $reportPath")
    println(s"Errors written to: $errorsPath")
  }
}
