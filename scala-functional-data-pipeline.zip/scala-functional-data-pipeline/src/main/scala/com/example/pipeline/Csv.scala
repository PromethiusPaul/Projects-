package com.example.pipeline

object Csv {
  def parseLine(line: String): List[String] = {
    @annotation.tailrec
    def loop(
        remaining: List[Char],
        current: Vector[Char],
        fields: Vector[String],
        inQuotes: Boolean
    ): Vector[String] = remaining match {
      case Nil => fields :+ current.mkString.trim
      case '"' :: '"' :: tail if inQuotes =>
        loop(tail, current :+ '"', fields, inQuotes)
      case '"' :: tail =>
        loop(tail, current, fields, !inQuotes)
      case ',' :: tail if !inQuotes =>
        loop(tail, Vector.empty, fields :+ current.mkString.trim, inQuotes)
      case head :: tail =>
        loop(tail, current :+ head, fields, inQuotes)
    }

    loop(line.toList, Vector.empty, Vector.empty, inQuotes = false).toList
  }
}
