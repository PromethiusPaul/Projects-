package com.example.pipeline

object Pipeline {
  def decode(lines: List[String]): List[(Int, String, Either[ValidationError, RawRecord])] =
    lines.zipWithIndex.collect {
      case (line, index) if line.trim.nonEmpty && index > 0 =>
        val lineNumber = index + 1
        val columns    = Csv.parseLine(line)

        val decoded = columns match {
          case id :: name :: department :: salary :: active :: Nil =>
            Right(RawRecord(id, name, department, salary, active))
          case _ =>
            Left(ValidationError(lineNumber, "Expected 5 CSV columns: id,name,department,salary,active", line))
        }

        (lineNumber, line, decoded)
    }

  def validate(records: List[(Int, String, Either[ValidationError, RawRecord])]): (List[ValidationError], List[EmployeeRecord]) = {
    val validated = records.map {
      case (lineNumber, rawLine, Right(raw)) => validateRecord(lineNumber, rawLine, raw)
      case (_, _, Left(error))               => Left(error)
    }

    val errors = validated.collect { case Left(error) => error }
    val valid  = validated.collect { case Right(record) => record }
    (errors, valid)
  }

  def summarize(records: List[EmployeeRecord]): List[DepartmentSummary] =
    records
      .groupBy(_.department)
      .toList
      .sortBy(_._1)
      .map { case (department, employees) =>
        val totalEmployees = employees.size
        val activeEmployees = employees.count(_.active)
        val totalSalary = employees.map(_.salary).foldLeft(BigDecimal(0))(_ + _)
        val averageSalary =
          if (totalEmployees == 0) BigDecimal(0)
          else (totalSalary / BigDecimal(totalEmployees)).setScale(2, BigDecimal.RoundingMode.HALF_UP)

        DepartmentSummary(
          department = department,
          totalEmployees = totalEmployees,
          activeEmployees = activeEmployees,
          averageSalary = averageSalary,
          totalSalary = totalSalary.setScale(2, BigDecimal.RoundingMode.HALF_UP)
        )
      }

  def buildReport(processed: Int, errors: List[ValidationError], summaries: List[DepartmentSummary]): PipelineReport =
    PipelineReport(
      processed = processed,
      valid = processed - errors.size,
      invalid = errors.size,
      summaries = summaries
    )

  private def validateRecord(lineNumber: Int, rawLine: String, raw: RawRecord): Either[ValidationError, EmployeeRecord] = {
    def parseInt(value: String, fieldName: String): Either[String, Int] =
      Either.catchOnly[NumberFormatException](value.trim.toInt).left.map(_ => s"$fieldName must be an integer")

    def parseSalary(value: String): Either[String, BigDecimal] =
      Either
        .catchOnly[NumberFormatException](BigDecimal(value.trim))
        .left
        .map(_ => "salary must be a valid decimal")
        .flatMap { salary =>
          Either.cond(salary >= 0, salary.setScale(2, BigDecimal.RoundingMode.HALF_UP), "salary must be non-negative")
        }

    def parseBoolean(value: String): Either[String, Boolean] =
      value.trim.toLowerCase match {
        case "true"  => Right(true)
        case "false" => Right(false)
        case _        => Left("active must be true or false")
      }

    val result = for {
      id <- parseInt(raw.id, "id")
      salary <- parseSalary(raw.salary)
      active <- parseBoolean(raw.active)
      name = raw.name.trim
      department = raw.department.trim
      _ <- Either.cond(name.nonEmpty, (), "name must not be empty")
      _ <- Either.cond(department.nonEmpty, (), "department must not be empty")
    } yield EmployeeRecord(id, name, department, salary, active)

    result.left.map(message => ValidationError(lineNumber, message, rawLine))
  }
}
