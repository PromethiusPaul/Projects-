package com.example.pipeline

import java.nio.charset.StandardCharsets
import java.nio.file.{Files, Path, Paths}
import scala.jdk.CollectionConverters._

object FileIO {
  def readLines(path: String): List[String] =
    Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8).asScala.toList

  def writeText(path: String, content: String): Unit = {
    val outputPath = Paths.get(path)
    Option(outputPath.getParent).foreach(Files.createDirectories)
    Files.write(outputPath, content.getBytes(StandardCharsets.UTF_8))
  }

  def exists(path: String): Boolean = Files.exists(Paths.get(path))
}
