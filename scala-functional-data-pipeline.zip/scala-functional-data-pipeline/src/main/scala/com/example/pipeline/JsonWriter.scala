package com.example.pipeline

object JsonWriter {
  def reportToJson(report: PipelineReport): String = {
    val summariesJson = report.summaries
      .map { summary =>
        s"""{
           |      \"department\": ${quote(summary.department)},
           |      \"totalEmployees\": ${summary.totalEmployees},
           |      \"activeEmployees\": ${summary.activeEmployees},
           |      \"averageSalary\": ${summary.averageSalary},
           |      \"totalSalary\": ${summary.totalSalary}
           |    }""".stripMargin
      }
      .mkString(",\n")

    s"""{
       |  \"processed\": ${report.processed},
       |  \"valid\": ${report.valid},
       |  \"invalid\": ${report.invalid},
       |  \"summaries\": [
       |$summariesJson
       |  ]
       |}""".stripMargin
  }

  def errorsToJson(errors: List[ValidationError]): String = {
    val entries = errors
      .map { error =>
        s"""{
           |    \"lineNumber\": ${error.lineNumber},
           |    \"message\": ${quote(error.message)},
           |    \"rawLine\": ${quote(error.rawLine)}
           |  }""".stripMargin
      }
      .mkString(",\n")

    s"""[
       |$entries
       |]""".stripMargin
  }

  private def quote(value: String): String =
    '"' + value.flatMap {
      case '"'  => "\\\""
      case '\\' => "\\\\"
      case '\n' => "\\n"
      case '\r' => "\\r"
      case '\t' => "\\t"
      case c    => c.toString
    } + '"'
}
