package com.example.pipeline

final case class RawRecord(id: String, name: String, department: String, salary: String, active: String)

final case class EmployeeRecord(
    id: Int,
    name: String,
    department: String,
    salary: BigDecimal,
    active: Boolean
)

final case class DepartmentSummary(
    department: String,
    totalEmployees: Int,
    activeEmployees: Int,
    averageSalary: BigDecimal,
    totalSalary: BigDecimal
)

final case class PipelineReport(
    processed: Int,
    valid: Int,
    invalid: Int,
    summaries: List[DepartmentSummary]
)

final case class ValidationError(lineNumber: Int, message: String, rawLine: String)
