# Scala Functional Data Pipeline

A GitHub-friendly Scala project that demonstrates a **functional data pipeline** using immutable data models, pure transformation stages, and explicit error handling with `Either`.

## What this project does

This pipeline reads employee data from a CSV file, validates and transforms each row into typed Scala models, aggregates the valid data by department, and writes the final results to JSON files.

### Pipeline stages
1. **Read** CSV input from `data/input/employees.csv`
2. **Decode** rows into raw immutable records
3. **Validate** fields with explicit functional error handling
4. **Transform** valid rows into typed domain models
5. **Summarize** by department
6. **Write** report and validation errors to JSON output files

## Why this is a good Scala portfolio project

It shows:
- immutable case classes
- pure data transformation functions
- functional error handling with `Either`
- separation of concerns across files
- typed domain modeling
- aggregation and reporting logic
- GitHub-ready project structure

## Project structure

```text
scala-functional-data-pipeline/
├── build.sbt
├── README.md
├── data/
│   ├── input/
│   │   └── employees.csv
│   └── output/
└── src/
    └── main/
        └── scala/
            └── com/
                └── example/
                    └── pipeline/
                        ├── Csv.scala
                        ├── FileIO.scala
                        ├── JsonWriter.scala
                        ├── Main.scala
                        ├── Models.scala
                        └── Pipeline.scala
```

## Requirements

- Java 11 or newer
- sbt 1.10+
- Scala 2.13

## How to run

From the project root:

```bash
sbt run
```

That uses the default paths:
- input: `data/input/employees.csv`
- report output: `data/output/report.json`
- error output: `data/output/errors.json`

## Run with custom file paths

```bash
sbt "run path/to/input.csv path/to/report.json path/to/errors.json"
```

## Example input

```csv
id,name,department,salary,active
1,Alice Johnson,Engineering,98000,true
2,Bob Smith,Engineering,105500,true
3,Carla Gomez,HR,72000,true
```

## Example output summary

After running, the project writes a report like this:

```json
{
  "processed": 10,
  "valid": 7,
  "invalid": 3,
  "summaries": [
    {
      "department": "Engineering",
      "totalEmployees": 2,
      "activeEmployees": 2,
      "averageSalary": 101750.00,
      "totalSalary": 203500.00
    }
  ]
}
```

## Files explained

### `Models.scala`
Defines immutable domain models and error models.

### `Csv.scala`
Contains a small CSV parser that supports quoted values.

### `Pipeline.scala`
Contains the pure pipeline stages:
- decode
- validate
- summarize
- build report

### `JsonWriter.scala`
Converts reports and errors into JSON strings.

### `FileIO.scala`
Handles reading and writing files.

### `Main.scala`
Application entry point that wires the stages together.

## How to customize it

You can extend this project by adding:
- filtering by department
- salary band analysis
- JSON input support
- streaming with FS2
- database output
- Cats Effect for effect management
- automated tests with ScalaTest or MUnit

## Suggested GitHub description

> Functional Scala data pipeline that reads CSV data, validates records with `Either`, transforms into typed models, and outputs JSON summaries.

## License

You can use this project as a portfolio piece, learning resource, or starting template for a larger Scala backend project.
