# Scalable Job Board Backend API

## Overview
Production-ready backend API demonstrating authentication and database architecture.

## Setup
npm install
cp .env_example_environment_variables .env
npm run dev
