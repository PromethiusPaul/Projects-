const repo = require('../repositories/user_database_repository');
const bcrypt = require('bcrypt');
const jwtUtil = require('../utils/jwt_token_utility');

exports.registerUserService = async ({ email, password }) => {
    const hashed = await bcrypt.hash(password, 10);
    return repo.createUser(email, hashed);
};

exports.loginUserService = async ({ email, password }) => {
    const user = await repo.findUserByEmail(email);
    if (!user) throw new Error('User not found');

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) throw new Error('Invalid credentials');

    return { token: jwtUtil.generateToken(user.id) };
};
