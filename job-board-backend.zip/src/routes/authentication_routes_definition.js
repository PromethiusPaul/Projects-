const express = require('express');
const router = express.Router();
const controller = require('../controllers/authentication_controller');

router.post('/register', controller.registerUserController);
router.post('/login', controller.loginUserController);

module.exports = router;
