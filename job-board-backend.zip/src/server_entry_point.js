const express = require('express');
const app = express();
require('dotenv').config();

const authRoutes = require('./routes/authentication_routes_definition');
const jobRoutes = require('./routes/job_routes_definition');

app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/jobs', jobRoutes);

app.listen(process.env.PORT, () => {
    console.log(`Server running on port ${process.env.PORT}`);
});
