const service = require('../services/authentication_business_logic_service');

exports.registerUserController = async (req, res) => {
    const result = await service.registerUserService(req.body);
    res.json(result);
};

exports.loginUserController = async (req, res) => {
    const result = await service.loginUserService(req.body);
    res.json(result);
};
